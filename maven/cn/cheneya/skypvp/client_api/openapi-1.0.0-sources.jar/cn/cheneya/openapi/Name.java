package cn.cheneya.openapi;

public class Name {
    public static String Name = "SKY PVP";
}
