package cn.cheneya.openapi;

public class Version {
    public static String Version = "1.0";
    public static String Version_Name = "MCP 1.21.4";
}
